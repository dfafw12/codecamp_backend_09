import {
  checkEmail,
  checkRegistrationNumber,
  getWelcomeTemplate,
  customRegistrationNumber,
} from "./util.js";

function welcomeTemplate(email, registrationNumber, phoneNum, FavorSite) {
  const EmailValid = checkEmail(email);
  if (EmailValid === false) {
    return;
  }
  const registrationNumValid = checkRegistrationNumber(registrationNumber);

  if (registrationNumValid === false) {
    console.log("!!!!!!!!!");
    return;
  }

  const myTemplate = getWelcomeTemplate(
    email,
    registrationNumber,
    phoneNum,
    FavorSite
  );

  console.log(myTemplate);
}

const email = "qwe@qwe.com";
const registrationNumber = "12226-1234567";
const phoneNum = "010-1234-1234";
const FavorSite = "naver.com";

welcomeTemplate(
  email,
  customRegistrationNumber(registrationNumber),
  phoneNum,
  FavorSite
);
